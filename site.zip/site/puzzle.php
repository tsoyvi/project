<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Личный сайт студента GeekBrains</title>
	<link rel="stylesheet" href="style.css"> 
</head>
<body>

<div class="content">
	<div class="header">
		<?php
	        include "menu.php";
	    ?>
	</div>

<div class="contentWrap">
    <div class="content">
        <div class="center">

			<h1>Игра в загадки</h1>

			<div class="box">
			    <?php
			        if (isset($_POST["userAnswer1"]) && isset($_POST["userAnswer2"]) && isset($_POST["userAnswer3"])) {
    			        $score = 0;
    			        
    			        if ($_POST["userAnswer1"] == "сон" || $_POST["userAnswer1"] == "сновидение") {
    			            $score++;
    			        }
    			        
    			        if ($_POST["userAnswer2"] == "морской" || $_POST["userAnswer2"] == "укус акулы") {
    			            $score++;
    			        }
    			        
    			        if ($_POST["userAnswer3"] == "шахматный" || $_POST["userAnswer3"] == "мертвый") {
    			            $score++;
    			        }
    			        
    			        echo "Вы угадали ".$score." загадок";
			        }
			    ?>
			    <form method="POST">
    				<p>Что можно увидеть с закрытыми глазами?</p>
    				<input type="text" name="userAnswer1">
    
    				<p>Какой болезнью никто не болеет на суше?</p>
    				<input type="text" name="userAnswer2">
    
    				<p>Какой конь не ест овса?</p>
    				<input type="text" name="userAnswer3">
    
    				<br>
    				<input type="submit" value="Ответить">
                </form>
			</div>

        </div>
    </div>
</div>

	

</div>
<?php
	    include "footer.php";
?>


</body>
</html>