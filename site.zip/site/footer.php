<div class="footer">
	Copyright &copy; <?php echo date("Y"); ?> Masha Ivanova
<div>