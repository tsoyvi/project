<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Генератор паролей</title>
	<link rel="stylesheet" href="style.css"> 
</head>
<body>

<div class="content">
	<div class="header">
		<?php
	        include "menu.php";
	    ?>
	</div>

<div class="contentWrap">
    <div class="content">
        <div class="center">

			<h1>Генератор паролей</h1>

			<div class="box">
			    <?php
			        function generatePassword($pass_length) {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); 
    $alphaLength = strlen($alphabet) - 1; 
    for ($i = 0; $i < $pass_length; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); 
}
			    
			        if (isset($_POST["pass_length"])) {
    			        echo "Ваш классный пароль <b>".generatePassword($_POST["pass_length"])."</b>";
			        }
			    ?>
			    <form method="POST">
    				<p>Введите количество символов для пароля</p>
    				<input type="text" name="pass_length">
                    <br />
    				<input type="submit" value="Поехали">
                </form>
			</div>

        </div>
    </div>
</div>

	

</div>
<?php
	    include "footer.php";
?>


</body>
</html>