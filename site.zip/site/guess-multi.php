<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Личный сайт студента GeekBrains</title>
	<link rel="stylesheet" href="style.css"> 
	<script type="text/javascript">

		var answer = parseInt(Math.random() * 100);
		var player = 1;
		var guessed = false;

		function readInt(){
			var number = document.getElementById("userAnswer").value;
			return number;
		}

		function write_info(text){
			document.getElementById("info").innerHTML = text;
		}

		function write_extra(text) {
			document.getElementById("extra").innerHTML = text;	
		}

		function hide(id){
			document.getElementById(id).style.display = "none";
		}

		function guess(){
			var userAnswer = readInt();
			if (userAnswer == "Q") {
				write_info("Игра прервана игроком " + player);
				hide("button");
				hide("userAnswer");
				hide("extra");
				guessed = true;
			} else {
				userAnswer = parseInt(userAnswer);
				if(userAnswer == answer){
					write_extra("<b>Поздравляю, вы угадали!</b> Победил игрок " + player);
					hide("button");
					hide("userAnswer");
					hide("info");
					guessed = true;
				} else if(userAnswer > answer){
					write_extra("Вы ввели слишком большое число.");
				} else if(userAnswer < answer){
					write_extra("Вы ввели слишком маленькое число.");				
				}
				if(player == 1){
	         	   player = 2;
	        	} else {
		        	player = 1;
	        	}
	        	if (!guessed)
	        		write_info("Угадайте число от 0 до 100.<br />Игра расчитана на двух игроков. Ходит игрок " + player + ".<br />Для выхода нажмите Q.");
	        }
		}

	</script>
</head>
<body>

<div class="content">
	<div class="header">
		<?php
	        include "menu.php";
	    ?>
	</div>

<div class="contentWrap">
    <div class="content">
        <div class="center">

			<h1>Игра угадайка-мультиплеер</h1>

			<div class="box">

				<p id="info">Угадайте число от 0 до 100.<br />Игра расчитана на двух игроков. Ходит игрок 1.<br />Для выхода нажмите Q.</p>
				<p id="extra"></p>
				<input type="text" id="userAnswer">
				<br>
				<a href="#" onClick="guess();" id="button">Начать</a>				
			</div>
        </div>
    </div>
</div>

	

</div>
<?php
	    include "footer.php";
?>


</body>
</html>