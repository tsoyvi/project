<div class="header">
		<a href="index.php">Главная</a>
		<a href="puzzle.php">Загадки</a>
    	<a href="guess-multi.php">Угадайка-мультиплеер</a>
		<a href="passwords.php">Генератор паролей</a>
	</div>